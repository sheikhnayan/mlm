
<?php
    $testimonialCaption = getContent('testimonial.content',true);
    $testimonials = getContent('testimonial.element');
?>

<section class="client-section padding-top padding-bottom">
    <div class="container">
        <div class="section-header">
            <h2 class="title"><?php echo app('translator')->get(@$testimonialCaption->data_values->heading); ?></h2>
            <p><?php echo app('translator')->get(@$testimonialCaption->data_values->sub_heading); ?></p>
        </div>
        <div class="client-slider">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <div class="client-item">
                            <blockquote>
                                <?php echo e(__(@$testimonial->data_values->quote)); ?>

                            </blockquote>
                            <div class="author">
                                <div class="author-thumb">
                                    <img src="<?php echo e(getImage('assets/images/frontend/testimonial/'.@$testimonial->data_values->image, '150x150')); ?>" alt="client">
                                </div>
                                <div class="author-content">
                                    <h6 class="title"><?php echo e(__(@$testimonial->data_values->author)); ?></h6>
                                    <span><?php echo e(__(@$testimonial->data_values->designation)); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>



<?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/sections/testimonial.blade.php ENDPATH**/ ?>