<?php
    $serviceCaption = getContent('service.content',true);
    $services = getContent('service.element');
?>
<?php if($services): ?>

    <section class="how-to-section padding-bottom padding-top section-bg">
        <div class="container">
            <div class="section-header">
                <h2 class="title"><?php echo app('translator')->get(@$serviceCaption->data_values->heading); ?></h2>
                <p><?php echo app('translator')->get(@$serviceCaption->data_values->sub_heading); ?></p>
            </div>
            <div class="row justify-content-center mb-30-none how-wrapper">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-10 col-md-6 col-lg-4">
                        <div class="how-item">
                            <div class="how-thumb">
                                <?php echo @$data->data_values->icon ?>
                            </div>
                            <div class="how-content">
                                <h5 class="title"><?php echo e(__(@$data->data_values->title)); ?></h5>
                                <p><?php echo e(__(@$data->data_values->description)); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/sections/service.blade.php ENDPATH**/ ?>