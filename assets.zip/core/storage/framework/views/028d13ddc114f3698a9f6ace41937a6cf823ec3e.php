<?php
    $breadcrumb = getContent('breadcrumb.content',true);
?>

<section class="page-header bg_img"
         data-background="<?php echo e(getImage('assets/images/frontend/breadcrumb/' . @$breadcrumb->data_values->background_image, '1920x600')); ?>">
    <div class="container">
        <div class="page-header-wrapper">
            <h2 class="title"><?php echo app('translator')->get($page_title); ?></h2>
            <ul class="breadcrumb">
                <li><a href="<?php echo e(url('/')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
                <li><?php echo app('translator')->get($page_title); ?></li>
            </ul>
        </div>
    </div>
</section>
<?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/layouts/breadcrumb.blade.php ENDPATH**/ ?>