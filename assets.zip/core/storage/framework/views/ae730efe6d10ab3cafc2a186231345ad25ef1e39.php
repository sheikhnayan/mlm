<?php $__env->startSection('content'); ?>

    <?php
        $sliders = getContent('slider.element');
    ?>
    <section class="banner-slider">
        <div class="swiper-wrapper">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <div class="banner-container bg-overlay bg_img" data-background="<?php echo e(getImage('assets/images/frontend/slider/' . @$slider->data_values->background_image, '1920x850')); ?>">
                        <div class="container">
                            <div class="banner-content">
                                <h3 class="sub-title"><?php echo e(__(@$slider->data_values->title)); ?></h3>
                                <h1 class="title"><?php echo e(__(@$slider->data_values->subtitle)); ?></h1>
                                <div class="button-area">
                                    <p><?php echo e(__(@$slider->data_values->description)); ?></p>
                                    <div class="button-group">
                                        <a href="<?php echo e(__(@$slider->data_values->left_button_link)); ?>" class="custom-button active"><?php echo e(__(@$slider->data_values->left_button)); ?></a>
                                        <a href="<?php echo e(__(@$slider->data_values->right_button_link)); ?>" class="custom-button"><?php echo e(__(@$slider->data_values->right_button)); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="banner-prev"><i class="fas fa-angle-left"></i></div>
        <div class="banner-next"><i class="fas fa-angle-right"></i></div>
    </section>

    <?php if($sections->secs != null): ?>
        <?php $__currentLoopData = json_decode($sections->secs); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make($activeTemplate.'sections.'.$sec, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>





<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/home.blade.php ENDPATH**/ ?>