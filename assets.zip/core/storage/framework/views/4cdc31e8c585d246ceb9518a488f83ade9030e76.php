

<div class="row align-items-center mb-30 justify-content-between">
    <div class="col-lg-6 col-sm-6">
        <h6 class="page-title"><?php echo e(__($page_title)); ?></h6>
    </div>
    <div class="col-lg-6 col-sm-6 text-sm-right mt-sm-0 mt-3 right-part">
        <?php echo $__env->yieldPushContent('breadcrumb-plugins'); ?>
    </div>
</div>
<?php /**PATH /home/safeworl/public_html/core/resources/views/admin/partials/breadcrumb.blade.php ENDPATH**/ ?>