<?php $__env->startSection('panel'); ?>
    <div class="container">
        <div class="row  justify-content-center">
            <div class="col-md-8">

                <div class="card card-deposit text-center">
                    <div class="card-body card-body-deposit">
                        <ul class="list-group text-center">
                            <li class="list-group-item " >
                                <img class="max-w-h-100px" src="<?php echo e($data->gateway_currency()->methodImage()); ?>" />
                            </li>
                            <p class="list-group-item">
                                <?php echo app('translator')->get('Amount'); ?>:
                                <strong><?php echo e(getAmount($data->amount)); ?> </strong> <?php echo e($general->cur_text); ?>

                            </p>
                            <p class="list-group-item">
                                <?php echo app('translator')->get('Charge'); ?>:
                                <strong><?php echo e(getAmount($data->charge)); ?></strong> <?php echo e($general->cur_text); ?>

                            </p>
                            <p class="list-group-item">
                                <?php echo app('translator')->get('Payable'); ?>: <strong> <?php echo e(getAmount($data->amount + $data->charge)); ?></strong> <?php echo e($general->cur_text); ?>

                            </p>
                            <p class="list-group-item">
                                <?php echo app('translator')->get('Conversion Rate'); ?>: <strong>1 <?php echo e($general->cur_text); ?> = <?php echo e(getAmount($data->rate)); ?>  <?php echo e($data->baseCurrency()); ?></strong>
                            </p>
                            <p class="list-group-item">
                                <?php echo app('translator')->get('In'); ?> <?php echo e($data->baseCurrency()); ?>:
                                <strong><?php echo e(getAmount($data->final_amo)); ?></strong>
                            </p>
                            <?php if($data->gateway->crypto==1): ?>
                                <p class="list-group-item">
                                    <?php echo app('translator')->get('Conversion with'); ?>
                                    <b> <?php echo e($data->method_currency); ?></b> <?php echo app('translator')->get('and final value will Show on next step'); ?>
                                </p>
                            <?php endif; ?>
                        </ul>

                        <?php if( 1000 >$data->method_code): ?>
                            <a href="<?php echo e(route('user.deposit.confirm')); ?>" class="btn btn--success btn-block py-3 font-weight-bold"><?php echo app('translator')->get('Confirm Deposit'); ?></a>
                        <?php else: ?>
                            <a href="<?php echo e(route('user.deposit.manual.confirm')); ?>" class="btn btn--success btn-block py-3 font-weight-bold"><?php echo app('translator')->get('Confirm Deposit'); ?></a>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make($activeTemplate . 'user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/user/payment/preview.blade.php ENDPATH**/ ?>