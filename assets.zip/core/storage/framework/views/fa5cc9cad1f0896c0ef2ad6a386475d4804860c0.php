<?php echo  tawkto() ?>
<?php echo  analytics() ?><?php /**PATH /home/safeworl/public_html/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>