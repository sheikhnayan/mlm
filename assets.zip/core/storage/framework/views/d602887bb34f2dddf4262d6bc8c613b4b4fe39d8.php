<?php $__env->startSection('panel'); ?>
    <div class="row mb-none-30">
        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-4 col-md-6 mb-30">
                <div class="card">
                    <div class="card-body pt-5 pb-5 ">
                        <div class="pricing-table text-center mb-4">
                            <h2 class="package-name mb-20 text-"><strong><?php echo app('translator')->get($data->name); ?></strong></h2>
                            <!--<span class="price text--dark font-weight-bold d-block"><?php echo e($general->cur_sym); ?><?php echo e(getAmount($data->price)); ?></span>-->
                            <hr>
                            <ul class="package-features-list mt-30">
                                <li><i class="fas fa-check bg--success"></i> <span><?php echo app('translator')->get('Business Volume (BV)'); ?>: <?php echo e(getAmount($data->bv)); ?>%</span>   <span class="icon" data-toggle="modal" data-target="#bvInfoModal"><i
                                            class="fas fa-question-circle"></i></span></li>
                                <li><i class="fas fa-check bg--success"></i> <span> <?php echo app('translator')->get('Referral Commission'); ?>: <?php echo e($general->cur_sym); ?> <?php echo e(getAmount($data->ref_com)); ?>% </span>
                                    <span class="icon" data-toggle="modal" data-target="#refComInfoModal"><i
                                    class="fas fa-question-circle"></i></span>
                                </li>
                                <li>
                                    <i class="fas <?php if(getAmount($data->tree_com) != 0): ?> fa-check bg--success <?php else: ?> fa-times bg--danger <?php endif; ?> "></i>  <span><?php echo app('translator')->get('Tree Commission'); ?>: <?php echo e($general->cur_sym); ?> <?php echo e(getAmount($data->tree_com)); ?>% </span>
                                     <span class="icon" data-toggle="modal" data-target="#treeComInfoModal"><i
                                    class="fas fa-question-circle"></i></span>
                                </li>
                                <li>
                                    <i class="fas <?php if(getAmount($data->daily_com) != 0): ?> fa-check bg--success <?php else: ?> fa-times bg--danger <?php endif; ?> "></i>  <span><?php echo app('translator')->get('Daily Commission'); ?>: <?php echo e($general->cur_sym); ?> <?php echo e(getAmount($data->daily_com)); ?>% </span>
                                     <span class="icon" data-toggle="modal" data-target="#dailyComInfoModal"><i
                                    class="fas fa-question-circle"></i></span>
                                </li>
                                <li>
                                    <i class="fas <?php if(getAmount($data->weekly_com) != 0): ?> fa-check bg--success <?php else: ?> fa-times bg--danger <?php endif; ?> "></i>  <span><?php echo app('translator')->get('Weekly Commission'); ?>: <?php echo e($general->cur_sym); ?> <?php echo e(getAmount($data->weekly_com)); ?>% </span>
                                     <span class="icon" data-toggle="modal" data-target="#weeklyComInfoModal"><i
                                    class="fas fa-question-circle"></i></span>
                                </li>
                                <li>
                                    <i class="fas <?php if(getAmount($data->monthly_com) != 0): ?> fa-check bg--success <?php else: ?> fa-times bg--danger <?php endif; ?> "></i>  <span><?php echo app('translator')->get('Monthly Commission'); ?>: <?php echo e($general->cur_sym); ?> <?php echo e(getAmount($data->monthly_com)); ?>% </span>
                                     <span class="icon" data-toggle="modal" data-target="#monthlyComInfoModal"><i
                                    class="fas fa-question-circle"></i></span>
                                </li>
                                <li>
                                    <i class="fas <?php if(getAmount($data->min_amount) != 0): ?> fa-check bg--success <?php else: ?> fa-times bg--danger <?php endif; ?> "></i>  <span><?php echo app('translator')->get('Minimum Deposit'); ?>: <?php echo e($general->cur_sym); ?> <?php echo e(getAmount($data->min_amount)); ?> </span>
                                     <span class="icon" data-toggle="modal" data-target="#min_deposit"><i
                                    class="fas fa-question-circle"></i></span>
                                </li>
                                <li>
                                    <i class="fas <?php if(getAmount($data->max_amount) != 0): ?> fa-check bg--success <?php else: ?> fa-times bg--danger <?php endif; ?> "></i>  <span><?php echo app('translator')->get('Maximum Deposit'); ?>: <?php echo e($general->cur_sym); ?> <?php echo e(getAmount($data->max_amount)); ?> </span>
                                     <span class="icon" data-toggle="modal" data-target="#max_deposit"><i
                                    class="fas fa-question-circle"></i></span>
                                </li>
                            </ul>
                        </div>
                        <?php if(Auth::user()->plan_id != $data->id): ?>
                            <a href="#confBuyModal<?php echo e($data->id); ?>" data-toggle="modal" class="btn w-100 btn-outline--primary  mt-20 py-2 box--shadow1"><?php echo app('translator')->get('Subscribe'); ?></a>
                        <?php else: ?>
                            <a data-toggle="modal" class="btn w-100 btn-outline--primary  mt-20 py-2 box--shadow1"><?php echo app('translator')->get('Already Subscribe'); ?></a>
                        <?php endif; ?>
                    </div>

                </div><!-- card end -->
            </div>


            <div class="modal fade" id="confBuyModal<?php echo e($data->id); ?>" tabindex="-1" role="dialog"
                 aria-labelledby="myModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="myModalLabel"> <?php echo app('translator')->get('Confirm Purchase '.$data->name); ?>?</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                    aria-hidden="true">×</span></button>
                        </div>
                        <div class="modal-body">
                            <!--<h5 class="text-danger text-center"><?php echo e(getAmount($data->price)); ?> <?php echo e($general->cur_text); ?> <?php echo app('translator')->get('will subtract from your balance'); ?></h5>-->
                        </div>
                        <form method="post" action="<?php echo e(route('user.plan.purchase')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <label>Please Select The Commission Type </label>
                                <select class="form-control" name="com_type" required>
                                    <option value="daily">Daily</option>
                                    <option value="weekly">Weekly</option>
                                    <option value="monthly">Monthly</option>
                                </select>
                                
                                <label> Please Enter The Deposit Amount </label>
                                <input type="number" max="<?php echo e(getAmount($data->max_amount)); ?>" min="<?php echo e(getAmount($data->min_amount)); ?>" class=""form-control name="amount"> 
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn--danger" data-dismiss="modal"><i
                                        class="fa fa-times"></i> <?php echo app('translator')->get('Close'); ?></button>

                                <button type="submit" name="plan_id" value="<?php echo e($data->id); ?>" class="btn btn--success"><i
                                        class="lab la-telegram-plane"></i> <?php echo app('translator')->get('Subscribe'); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="modal fade" id="bvInfoModal">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get("Business Volume (BV) info"); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo app('translator')->get('Close'); ?>">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h5 class="text-danger"><?php echo app('translator')->get('When someone from your below tree subscribe this plan, You will get this Business Volume  which will be used for matching bonus'); ?>.
                    </h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="refComInfoModal">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Referral Commission info'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h5><span
                            class=" text-danger"><?php echo app('translator')->get('When your referred user subscribe in'); ?> <b> <?php echo app('translator')->get('ANY PLAN'); ?></b>, <?php echo app('translator')->get('you will get this amount'); ?>.</span>
                        <br>
                        <br>
                        <span class="text-success"> <?php echo app('translator')->get('This is the reason you should choose a plan with bigger referral commission'); ?>.</span>
                    </h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="treeComInfoModal">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Commission to tree info'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h5 class=" text-danger"><?php echo app('translator')->get('When someone from your below tree subscribe this plan, You will get this amount as tree commission'); ?>. </h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>
     <div class="modal fade" id="dailyComInfoModal">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Daily Commission info'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h5 class=" text-danger"><?php echo app('translator')->get('When someone buys this plan, He will get this amount comission added to his wallet daily'); ?>. </h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="weeklyComInfoModal">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Weekly Commission info'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h5 class=" text-danger"><?php echo app('translator')->get('When someone buys this plan, He will get this amount comission added to his wallet weekly'); ?>. </h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="monthlyComInfoModal">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Monthly Commission info'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h5 class=" text-danger"><?php echo app('translator')->get('When someone buys this plan, He will get this amount comission added to his wallet monthly'); ?>. </h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="min_deposit">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Minimum Deposit info'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h5 class=" text-danger"><?php echo app('translator')->get('If Someone wants to but this,He have to minimum this amount!  '); ?>. </h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="max_deposit">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Maximum Deposit info'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h5 class=" text-danger"><?php echo app('translator')->get('If Someone wants to but this,He have to maximum this amount!  '); ?>. </h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate . 'user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic//user/plan.blade.php ENDPATH**/ ?>