<?php
    $subscribe = getContent('subscribe.content', true);
?>

<section id="subscribe" class="subscribe-section padding-top padding-bottom bg-overlay bg_img bg_fixed"
         data-background="<?php echo e(getImage('assets/images/frontend/subscribe/' . @$subscribe->data_values->background_image, '1920x475')); ?>">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="subscribe-content">
                    <h4 class="title"><?php echo app('translator')->get(@$subscribe->data_values->heading); ?></h4>
                    <form class="subscribe-form" method="post" action="<?php echo e(route('subscriber.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="email" name="email"  placeholder="<?php echo app('translator')->get('Enter Your email address'); ?>" required>
                        <button type="submit">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/sections/subscribe.blade.php ENDPATH**/ ?>