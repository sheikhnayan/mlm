<?php

    $planTitle = getContent('mlmPlan.content', true);
    $plans = \App\Models\Plan::where('status', 1)->get();

?>


<section class="pricing-section padding-bottom padding-top">
    <div class="container">
        <div class="section-header">
            <h2 class="title"><?php echo app('translator')->get(@$planTitle->data_values->heading); ?></h2>
            <p><?php echo app('translator')->get(@$planTitle->data_values->sub_heading); ?></p>
        </div>

        <div class="row justify-content-center mb-30-none">
            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 col-sm-10 mb-30">
                <div class="plan-card text-center bg_img" data-background="<?php echo e(asset(getImage('assets/images/frontend/mlmPlan/' . @$planTitle->data_values->background_image))); ?>">
                    <h4 class="plan-card__title mb-2"><?php echo e(__(@$plan->name)); ?></h4>
                    <div class="price-range text-white mt-5"> <?php echo e(getAmount($plan->price)); ?>  <?php echo e($general->cur_text); ?> </div>
                    <ul class="plan-card__features mt-4">
                     <li>   <?php echo app('translator')->get('Business Volume'); ?> (<?php echo app('translator')->get('BV'); ?>) : <span class="amount"><?php echo e($plan->bv); ?></span>
                         <span class="icon float-right" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-question-circle"></i></span></li>
                        <li>
                            <?php echo app('translator')->get('Referral Commission'); ?> : <span class="amount"><?php echo e($general->cur_sym); ?> <?php echo e(getAmount($plan->ref_com)); ?></span>
                            <span class="icon float-right" data-toggle="modal" data-target="#exampleModal2" ><i class="fas fa-question-circle"></i></span>
                        </li>

                        <li>
                            <?php echo app('translator')->get('Commission To Tree'); ?> : <span class="amount"><?php echo e($general->cur_sym); ?> <?php echo e(getAmount($plan->tree_com)); ?></span>
                            <span class="icon float-right" data-toggle="modal" data-target="#exampleModal3"><i class="fas fa-question-circle"></i></span>
                        </li>
                    </ul>

                    <a href="<?php echo e(route('user.plan.index')); ?>" class="custom-button theme text-white mt-3"><?php echo app('translator')->get('Subscribe now'); ?></a>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
</section>





<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo app('translator')->get("Business Volume (BV) info"); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5>   <span class="text-danger"><?php echo app('translator')->get('When someone from your below tree subscribe this plan, You will get this Business Volume  which will be used for matching bonus'); ?>.</span>
                </h5>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo app('translator')->get('Referral Commission info'); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5>  <span class=" text-danger"><?php echo app('translator')->get('When Your Direct-Referred/Sponsored  User Subscribe in'); ?> <b> <?php echo app('translator')->get('ANY PLAN'); ?> </b>, <?php echo app('translator')->get('You will get this amount'); ?>.</span>
                    <br>
                    <br>
                    <span class="text-success"> <?php echo app('translator')->get('This is the reason You should Choose a Plan With Bigger Referral Commission'); ?>.</span> </h5>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
            </div>
        </div>
    </div>
</div>



<div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo app('translator')->get('Commission to tree info'); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5 class=" text-danger"><?php echo app('translator')->get('When someone from your below tree subscribe this plan, You will get this amount as Tree Commission'); ?>. </h5>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
            </div>
        </div>
    </div>
</div>


<?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/sections/mlmPlan.blade.php ENDPATH**/ ?>