<?php

    $works = getContent('how_it_works.element');
    $workCaption = getContent('how_it_works.content',true);
?>
<?php if($works): ?>

    <section class="feature-section padding-top padding-bottom">
        <div class="container">
            <div class="section-header">
                <h2 class="title"><?php echo app('translator')->get(@$workCaption->data_values->heading); ?></h2>
                <p><?php echo app('translator')->get(@$workCaption->data_values->sub_heading); ?></p>
            </div>
            <div class="row justify-content-center mb-30-none">
                <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-4 col-md-6 col-sm-10">
                        <div class="feature-item">
                            <div class="feature-header">
                                <div class="icon">
                                    <?php echo @$data->data_values->icon ?>
                                </div>
                                <h6 class="title"><?php echo e(__(@$data->data_values->title)); ?></h6>
                            </div>
                            <div class="feature-body">
                                <p><?php echo e(__(@$data->data_values->description)); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>



<?php endif; ?>

<?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/sections/how_it_works.blade.php ENDPATH**/ ?>