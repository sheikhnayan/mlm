<?php $__env->startSection('content'); ?>

    <?php echo $__env->make($activeTemplate.'layouts.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="account-section padding-bottom padding-top">
        <div class="container">
            <div class="account-wrapper">
                <div class="signup-area account-area">
                    <div class="row m-0 flex-wrap-reverse">
                        <div class="col-lg-6 p-0">
                            <div class="change-catagory-area bg_img"
                                 data-background="<?php echo e(getImage('assets/images/frontend/sign_in/' . @$content->data_values->background_image, '650x600')); ?>">
                                <h4 class="title"><?php echo e(__(@$content->data_values->register_section_title)); ?></h4>
                                <p><?php echo e(__(@$content->data_values->register_section_short_details)); ?></p>
                                <a href="<?php echo e(route('user.register')); ?>"
                                   class="custom-button account-control-button"><?php echo app('translator')->get('Sign Up'); ?></a>
                            </div>
                        </div>
                        <div class="col-lg-6 p-0">
                            <div class="common-form-style bg-one login-account">
                                <h4 class="title"><?php echo e(__(@$content->data_values->title)); ?></h4>
                                <p class="mb-sm-4 mb-3"><?php echo e(__(@$content->data_values->short_details)); ?></p>
                                <form class="create-account-form" method="post" action="<?php echo e(route('user.login')); ?>"
                                      onsubmit="return submitUserForm();">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <input type="text" name="username" value="<?php echo e(old('username')); ?>"
                                               placeholder="<?php echo app('translator')->get('Username'); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" id="myInputThree" name="password"
                                               placeholder="<?php echo app('translator')->get('Password'); ?>" required>
                                        <a href="javascript:void(0)" class="show-pass show-pass-three"><i class="fas fa-eye"></i></a>
                                    </div>

                                    <?php if(reCaptcha()): ?>
                                        <div class="form-group my-3">
                                            <?php echo reCaptcha(); ?>
                                        </div>
                                    <?php endif; ?>

                                    <?php echo $__env->make($activeTemplate.'partials.custom-captcha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                    <div class="form-group d-flex flex-wrap justify-content-between align-items-center">
                                        <ul class="lost-pass m-0 pt-3">
                                            <li class="w-100">
                                                <a href="<?php echo e(route('user.password.request')); ?>"><?php echo app('translator')->get('Forget Password?'); ?></a>
                                            </li>
                                        </ul>
                                        <input type="submit" value="<?php echo app('translator')->get('Login Account'); ?>">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        function submitUserForm() {
            var response = grecaptcha.getResponse();
            if (response.length == 0) {
                document.getElementById('g-recaptcha-error').innerHTML = '<span class="text-danger"><?php echo app('translator')->get("Captcha field is required."); ?></span>';
                return false;
            }
            return true;
        }
        function verifyCaptcha() {
            document.getElementById('g-recaptcha-error').innerHTML = '';
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/user/auth/login.blade.php ENDPATH**/ ?>