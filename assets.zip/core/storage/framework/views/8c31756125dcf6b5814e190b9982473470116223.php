<?php $__env->startSection('panel'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card b-radius--10 overflow-hidden">
                <div class="card-body p-0">
                    <div class="table-responsive--sm">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Paid left'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Paid right'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Free left'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Free right'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Bv left'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Bv right'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Paid left'); ?>"><?php echo e($logs->paid_left); ?></td>
                                <td data-label="<?php echo app('translator')->get('Paid right'); ?>"><?php echo e($logs->paid_right); ?></td>
                                <td data-label="<?php echo app('translator')->get('Free left'); ?>"><?php echo e($logs->free_left); ?></td>
                                <td data-label="<?php echo app('translator')->get('Free right'); ?>"><?php echo e($logs->free_right); ?></td>
                                <td data-label="<?php echo app('translator')->get('Bv left'); ?>"><?php echo e(getAmount($logs->bv_left)); ?></td>
                                <td data-label="<?php echo app('translator')->get('Bv right'); ?>"><?php echo e(getAmount($logs->bv_right)); ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate . 'user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic//user/binarySummery.blade.php ENDPATH**/ ?>