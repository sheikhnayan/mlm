<?php

    $teamTitle = getContent('team.content', true);
    $teams = getContent('team.element');
?>


<section class="team-section padding-top padding-bottom section-bg">
    <div class="container">
        <div class="section-header">
            <h2 class="title"><?php echo app('translator')->get(@$teamTitle->data_values->heading); ?></h2>
            <p><?php echo app('translator')->get(@$teamTitle->data_values->sub_heading); ?></p>
        </div>
        <div class="row justify-content-center mb-30-none">
            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6 col-sm-9">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="<?php echo e(getImage('assets/images/frontend/team/'. @$team->data_values->image, '524x614')); ?>" alt="team">
                        </div>
                        <div class="team-content">
                            <h6 class="title">
                                <?php echo app('translator')->get(@$team->data_values->name); ?>
                            </h6>
                            <span class="info"><?php echo e(@$team->data_values->designation); ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>



<?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/sections/team.blade.php ENDPATH**/ ?>