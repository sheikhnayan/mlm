
<div class="sidebar capsule--rounded bg_img overlay--dark"
     data-background="<?php echo e(asset('assets/admin/images/sidebar/2.jpg')); ?>">
    <button class="res-sidebar-close-btn"><i class="las la-times"></i></button>
    <div class="sidebar__inner">
        <div class="sidebar__logo">
            <a href="<?php echo e(route('user.home')); ?>" class="sidebar__main-logo"><img
                    src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="<?php echo app('translator')->get('image'); ?>"></a>
            <a href="<?php echo e(route('user.home')); ?>" class="sidebar__logo-shape"><img
                    src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/favicon.png')); ?>" alt="<?php echo app('translator')->get('image'); ?>"></a>
            <button type="button" class="navbar__expand"></button>
        </div>
        <div class="sidebar__menu-wrapper" id="sidebar__menuWrapper">
            <ul class="sidebar__menu">
                <li class="sidebar-menu-item <?php echo e(menuActive('user.home')); ?>">
                    <a href="<?php echo e(route('user.home')); ?>" class="nav-link ">
                        <i class="menu-icon las la-home"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Dashboard'); ?></span>
                    </a>
                </li>
                <li class="sidebar-menu-item <?php echo e(menuActive('user.plan.index')); ?>">
                    <a href="<?php echo e(route('user.plan.index')); ?>" class="nav-link ">
                        <i class="menu-icon las la-lightbulb"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Plan'); ?></span>
                    </a>
                </li>



                <li class="sidebar-menu-item <?php echo e(menuActive('user.bv.log')); ?>">
                    <a href="<?php echo e(route('user.bv.log')); ?>" class="nav-link">
                        <i class="menu-icon las la-sitemap"></i>
                        <span class="menu-title"><?php echo app('translator')->get('BV Log'); ?></span>
                    </a>
                </li>
                <li class="sidebar-menu-item <?php echo e(menuActive('user.my.ref')); ?>">
                    <a href="<?php echo e(route('user.my.ref')); ?>" class="nav-link">
                        <i class="menu-icon las la-users"></i>
                        <span class="menu-title"><?php echo app('translator')->get('My Referrals'); ?></span>
                    </a>
                </li>
                <li class="sidebar-menu-item <?php echo e(menuActive('user.my.tree')); ?>">
                    <a href="<?php echo e(route('user.my.tree')); ?>" class="nav-link">
                        <i class="menu-icon las la-tree"></i>
                        <span class="menu-title"><?php echo app('translator')->get('My Tree'); ?></span>
                    </a>
                </li>
                <li class="sidebar-menu-item <?php echo e(menuActive('user.binary.summery')); ?>">
                    <a href="<?php echo e(route('user.binary.summery')); ?>" class="nav-link">
                        <i class=" menu-icon las la-chart-area"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Binary Summery'); ?></span>
                    </a>
                </li>
                <li class="sidebar-menu-item <?php echo e(menuActive('user.deposit')); ?>">
                    <a href="<?php echo e(route('user.deposit')); ?>" class="nav-link">
                        <i class=" menu-icon las la-credit-card"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Deposit Now'); ?></span>
                    </a>
                </li>
                <li class="sidebar-menu-item <?php echo e(menuActive('user.withdraw')); ?>">
                    <a href="<?php echo e(route('user.withdraw')); ?>" class="nav-link">
                        <i class="menu-icon las la-cloud-download-alt"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Withdraw Now'); ?></span>
                    </a>
                </li>
                <li class="sidebar-menu-item <?php echo e(menuActive('user.balance.transfer')); ?>">
                    <a href="<?php echo e(route('user.balance.transfer')); ?>" class="nav-link">
                        <i class="menu-icon las la-hand-holding-usd"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Balance Transfer'); ?></span>
                    </a>
                </li>
                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive('user.report*',3)); ?> my-2">
                        <i class="menu-icon las la-exchange-alt"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Reports'); ?> / <?php echo app('translator')->get('Logs'); ?></span>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive('user.report*',2)); ?> ">
                        <ul>
                            <li class="sidebar-menu-item <?php echo e(menuActive('user.report.transactions')); ?> ">
                                <a href="<?php echo e(route('user.report.transactions')); ?>" class="nav-link">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Transactions Log'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('user.report.deposit')); ?>">
                                <a href="<?php echo e(route('user.report.deposit')); ?>" class="nav-link">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Deposit Log'); ?></span>
                                </a>
                            </li>
                            
                            <li class="sidebar-menu-item <?php echo e(menuActive('user.report.commission')); ?>">
                                <a href="<?php echo e(route('user.report.commission')); ?>" class="nav-link">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Commission Log'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('user.report.withdraw')); ?>">
                                <a href="<?php echo e(route('user.report.withdraw')); ?>" class="nav-link">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Withdraw Log'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('user.report.invest')); ?>">
                                <a href="<?php echo e(route('user.report.invest')); ?>" class="nav-link">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Invest Log'); ?></span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive('user.report.refCom')); ?>">
                                <a href="<?php echo e(route('user.report.refCom')); ?>" class="nav-link">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Referral Commissions'); ?></span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive('user.report.binaryCom')); ?>">
                                <a href="<?php echo e(route('user.report.binaryCom')); ?>" class="nav-link">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Binary Commission'); ?></span>
                                </a>
                            </li>

                        </ul>
                    </div>
                </li>
                
                
                
                
                
                
                
                
                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="my-2">
                        <i class="menu-icon las la-exchange-alt"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Informations'); ?> / <?php echo app('translator')->get('Info'); ?></span>
                    </a>
                    <div class="sidebar-submenu">
                        <ul>
                            <li class="sidebar-menu-item">
                                <a href="#" class="nav-link" data-toggle="modal" data-target="#reffer">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Reffer & Binary'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item">
                                <a href="#" class="nav-link" data-toggle="modal" data-target="#investment">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Investment Profit'); ?></span>
                                </a>
                            </li>
                            
                            <li class="sidebar-menu-item">
                                <a href="#" class="nav-link" data-toggle="modal" data-target="#monthly">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Monthly  Leadership'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item">
                                <a href="#" class="nav-link" data-toggle="modal" data-target="#rank">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Rank Requirement'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item">
                                <a href="#" class="nav-link" data-toggle="modal" data-target="#royalty">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Royalty'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                <li class="sidebar-menu-item <?php echo e(menuActive('user.twofactor')); ?>">
                    <a href="<?php echo e(route('user.twofactor')); ?>" class="nav-link">
                        <i class="menu-icon las la-shield-alt"></i>
                        <span class="menu-title"><?php echo app('translator')->get('2FA Security'); ?></span>
                    </a>
                </li>

                <li class="sidebar-menu-item <?php echo e(menuActive('ticket')); ?>">
                    <a href="<?php echo e(route('ticket')); ?>" class="nav-link">
                        <i class="menu-icon las la-ticket-alt"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Support'); ?></span>
                    </a>
                </li>

                <li class="sidebar-menu-item <?php echo e(menuActive('user.profile-setting')); ?>">
                    <a href="<?php echo e(route('user.profile-setting')); ?>" class="nav-link">
                        <i class="menu-icon las la-user"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Profile'); ?></span>
                    </a>
                </li>
                <li class="sidebar-menu-item <?php echo e(menuActive('user.login.history')); ?>">
                    <a href="<?php echo e(route('user.login.history')); ?>" class="nav-link">
                        <i class="menu-icon las la-user"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Login History'); ?></span>
                    </a>
                </li>
                <li class="sidebar-menu-item">
                    <a href="<?php echo e(route('user.logout')); ?>" class="nav-link">
                        <i class="menu-icon las la-sign-out-alt"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Logout'); ?></span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="reffer" tabindex="-1" role="dialog" aria-labelledby="reffer" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Reffer & Binary</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <img src="<?php echo e(asset('assets/images/reffer.jpeg')); ?>">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="investment" tabindex="-1" role="dialog" aria-labelledby="investment" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Investment Profit</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <img src="<?php echo e(asset('assets/images/invesment.jpeg')); ?>">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="monthly" tabindex="-1" role="dialog" aria-labelledby="monthly" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Monthly Leadership</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <img src="<?php echo e(asset('assets/images/monthly.jpeg')); ?>">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="rank" tabindex="-1" role="dialog" aria-labelledby="rank" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Rank Requirement</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <img src="<?php echo e(asset('assets/images/rank.jpeg')); ?>">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="royalty" tabindex="-1" role="dialog" aria-labelledby="royalty" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Royalty</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <img src="<?php echo e(asset('assets/images/royalty.jpeg')); ?>">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div><?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/user/partials/sidenav.blade.php ENDPATH**/ ?>