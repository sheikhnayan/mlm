<?php $__env->startSection('panel'); ?>
    <div class="row mb-30">
        <div class="col-lg-12 col-md-12 mb-30">
            <div class="card">
                <div class="card-body">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="form-control-label font-weight-bold"> <?php echo app('translator')->get('Site Title'); ?> </label>
                                    <input class="form-control form-control-lg" type="text" name="sitename" value="<?php echo e($general->sitename); ?>">
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Currency'); ?></label>
                                    <input class="form-control  form-control-lg" type="text" name="cur_text"
                                           value="<?php echo e($general->cur_text); ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Currency Symbol'); ?></label>
                                    <input class="form-control  form-control-lg" type="text" name="cur_sym"
                                           value="<?php echo e($general->cur_sym); ?>">
                                </div>
                            </div>

                            <div class="form-group col-md-4">
                                <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Site Base Color'); ?></label>
                                <div class="input-group">
                                <span class="input-group-addon ">
                                    <input type='text' class="form-control  form-control-lg colorPicker"
                                           value="<?php echo e($general->base_color); ?>"/>
                                </span>
                                    <input type="text" class="form-control form-control-lg colorCode" name="base_color"
                                           value="<?php echo e($general->base_color); ?>"/>
                                </div>
                            </div>


                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Balance transfer fixed charge'); ?></label>
                                    <input class="form-control  form-control-lg" type="text" name="bal_trans_fixed_charge"
                                           value="<?php echo e(getAmount($general->bal_trans_fixed_charge)); ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Balance transfer Percent charge'); ?></label>
                                    <input class="form-control  form-control-lg" type="text" name="bal_trans_per_charge"
                                           value="<?php echo e(getAmount($general->bal_trans_per_charge)); ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('User Registration'); ?></label>
                                    <input type="checkbox" data-width="100%" data-size="large" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Enable'); ?>" data-off="<?php echo app('translator')->get('Disabled'); ?>" name="registration" <?php if($general->registration): ?> checked <?php endif; ?>>
                                </div>
                            </div>

                            <div class="form-group col-md-4">
                                <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Force Secure Password'); ?></label>
                                <input type="checkbox" data-width="100%" data-size="large" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Enable'); ?>" data-off="<?php echo app('translator')->get('Disabled'); ?>" name="secure_password" <?php if($general->secure_password): ?> checked <?php endif; ?>>
                            </div>

                            <div class="form-group col-md-4">
                                <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Force SSL'); ?></label>
                                <input type="checkbox" data-width="100%" data-size="large" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Enable'); ?>" data-off="<?php echo app('translator')->get('Disabled'); ?>" name="force_ssl" <?php if($general->force_ssl): ?> checked <?php endif; ?>>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-lg-3 col-sm-6 col-md-4">
                                <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Email Verification'); ?></label>
                                <input type="checkbox" data-width="100%" data-size="large" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Enable'); ?>" data-off="Disable" name="ev" <?php if($general->ev): ?> checked <?php endif; ?>>
                            </div>
                            <div class="form-group col-lg-3 col-sm-6 col-md-4">
                                <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Email Notification'); ?></label>
                                <input type="checkbox" data-width="100%" data-size="large" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Enable'); ?>" data-off="Disable" name="en" <?php if($general->en): ?> checked <?php endif; ?>>
                            </div>
                            <div class="form-group col-lg-3 col-sm-6 col-md-4">
                                <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('SMS Verification'); ?></label>
                                <input type="checkbox" data-width="100%" data-size="large" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Enable'); ?>" data-off="Disable" name="sv" <?php if($general->sv): ?> checked <?php endif; ?>>
                            </div>
                            <div class="form-group col-lg-3 col-sm-6 col-md-4">
                                <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('SMS Notification'); ?></label>
                                <input type="checkbox" data-width="100%" data-size="large" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Enable'); ?>" data-off="Disable" name="sn" <?php if($general->sn): ?> checked <?php endif; ?>>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn--primary btn-block btn-lg"><?php echo app('translator')->get('Update'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


      <div class="row ">

        <div class="col-lg-12 mb-30">
            <div class="card">
                  <div class="card-header ">
                    <h4 class="card-title font-weight-normal"><?php echo app('translator')->get('Matching Bonus'); ?></h4>
                </div>
                <form action="<?php echo e(route('admin.matching-bonus.update')); ?>" method="post">
                    <div class="card-body">
                        <?php echo csrf_field(); ?>
                        <div class="row justify-content-between mb-5">
                            <div class="col-md-4">
                                <div class="input-group custom-height">
                                    <input type="text" class="form-control form-control-lg" value="<?php echo e($general->total_bv); ?>"
                                           name="total_bv" id="#" aria-describedby="#" required="">
                                    <div class="input-group-append">
                                        <span class="input-group-text" id="#"><?php echo app('translator')->get('BV'); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-1">
                                <h2 class="text-center">=</h2>
                            </div>
                            <div class="col-md-3 mb-4">
                                <div class="input-group custom-height">
                                    <input type="text" class="form-control form-control-lg" name="bv_price"
                                           value="<?php echo e($general->bv_price); ?>" aria-describedby="#" required="">
                                    <div class="input-group-append">
                                        <span class="input-group-text" id="#"><?php echo e($general->cur_text); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="input-group mb-3 custom-height">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><?php echo app('translator')->get('MAX'); ?></span>
                                    </div>
                                    <input type="text" class="form-control form-control-lg" value="<?php echo e($general->max_bv); ?>"
                                           name="max_bv"
                                           aria-label="Amount (to the nearest dollar)">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><?php echo app('translator')->get('BV'); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-4">
                                <label><?php echo app('translator')->get('Carry / Flush'); ?></label>
                                <select class="form-control form-control-lg" name="cary_flash" required>
                                    <option value="0"><?php echo app('translator')->get('Carry (Cut Only Paid BV)'); ?></option>
                                    <option value="1"><?php echo app('translator')->get('Flush (Cut Weak Leg Value)'); ?></option>
                                    <option value="2"><?php echo app('translator')->get('Flush (Cut All BV and reset to 0)'); ?></option>
                                </select>
                            </div>
                            <div class="form-group col-md-4 ">
                                <label><?php echo app('translator')->get('Matching Bonus Time'); ?></label>
                                <select name="matching_bonus_time" class="form-control form-control-lg">
                                    <option value="daily"><?php echo app('translator')->get('Daily'); ?></option>
                                    <option value="weekly"><?php echo app('translator')->get('Weekly'); ?></option>
                                    <option value="monthly"><?php echo app('translator')->get('Monthly'); ?></option>
                                </select>
                            </div>
                            <div class="form-group col-md-4" id="daily_time" style="display:none;">
                                <label><?php echo app('translator')->get('Daily Time'); ?></label>
                                <select name="daily_time" class="form-control form-control-lg">
                                    <option value="1"><?php echo app('translator')->get('01:00'); ?></option>
                                    <option value="2"><?php echo app('translator')->get('02:00'); ?></option>
                                    <option value="3"><?php echo app('translator')->get('03:00'); ?></option>
                                    <option value="4"><?php echo app('translator')->get('04:00'); ?></option>
                                    <option value="5"><?php echo app('translator')->get('05:00'); ?></option>
                                    <option value="6"><?php echo app('translator')->get('06:00'); ?></option>
                                    <option value="7"><?php echo app('translator')->get('07:00'); ?></option>
                                    <option value="8"><?php echo app('translator')->get('08:00'); ?></option>
                                    <option value="9"><?php echo app('translator')->get('09:00'); ?></option>
                                    <option value="10"><?php echo app('translator')->get('10:00'); ?></option>
                                    <option value="11"><?php echo app('translator')->get('11:00'); ?></option>
                                    <option value="12"><?php echo app('translator')->get('12:00'); ?></option>
                                    <option value="13"><?php echo app('translator')->get('13:00'); ?></option>
                                    <option value="14"><?php echo app('translator')->get('14:00'); ?></option>
                                    <option value="15"><?php echo app('translator')->get('15:00'); ?></option>
                                    <option value="16"><?php echo app('translator')->get('16:00'); ?></option>
                                    <option value="17"><?php echo app('translator')->get('17:00'); ?></option>
                                    <option value="18"><?php echo app('translator')->get('18:00'); ?></option>
                                    <option value="19"><?php echo app('translator')->get('19:00'); ?></option>
                                    <option value="20"><?php echo app('translator')->get('20:00'); ?></option>
                                    <option value="21"><?php echo app('translator')->get('21:00'); ?></option>
                                    <option value="22"><?php echo app('translator')->get('22:00'); ?></option>
                                    <option value="23"><?php echo app('translator')->get('23:00'); ?></option>
                                    <option value="24"><?php echo app('translator')->get('24:00'); ?></option>
                                </select>
                            </div>
                            <div class="form-group col-md-4" id="weekly_time" style="display:none;">
                                <label><?php echo app('translator')->get('Weekly Time'); ?></label>
                                <select name="weekly_time" class="form-control form-control-lg">
                                    <option value="sat"><?php echo app('translator')->get('Saturday'); ?></option>
                                    <option value="sun"><?php echo app('translator')->get('Sunday'); ?></option>
                                    <option value="mon"><?php echo app('translator')->get('Monday'); ?></option>
                                    <option value="tue"><?php echo app('translator')->get('Tuesday'); ?></option>
                                    <option value="wed"><?php echo app('translator')->get('Wednesday'); ?></option>
                                    <option value="thu"><?php echo app('translator')->get('Thursday'); ?></option>
                                    <option value="fri"><?php echo app('translator')->get('Friday'); ?></option>
                                </select>
                            </div>
                            <div class="form-group col-md-4" id="monthly_time" style="display:none;">
                                <label><?php echo app('translator')->get('Monthly Time'); ?></label>
                                <select name="monthly_time" class="form-control form-control-lg">
                                    <option value="1"><?php echo app('translator')->get('1st day Month'); ?></option>
                                    <option value="15"><?php echo app('translator')->get('15th day of Month'); ?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="form-group col-md-12 text-center">
                            <button type="submit" class="btn btn--primary btn-block btn-lg"><?php echo app('translator')->get('Update'); ?></button>
                        </div>
                    </div>


                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset('assets/admin/js/spectrum.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style-lib'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/spectrum.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('style'); ?>
    <style>
        .sp-replacer {
            padding: 0;
            border: 1px solid rgba(0, 0, 0, .125);
            border-radius: 5px 0 0 5px;
            border-right: none;
        }

        .sp-preview {
            width: 100px;
            height: 46px;
            border: 0;
        }

        .sp-preview-inner {
            width: 110px;
        }

        .sp-dd {
            display: none;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        (function($){
            $('.colorPicker').spectrum({
                color: $(this).data('color'),
                change: function (color) {
                    $(this).parent().siblings('.colorCode').val(color.toHexString().replace(/^#?/, ''));
                }
            });

            $('.colorCode').on('input', function () {
                var clr = $(this).val();
                $(this).parents('.input-group').find('.colorPicker').spectrum({
                    color: clr,
                });
            });

            $("select[name=cary_flash]").val("<?php echo e($general->cary_flash); ?>");
            $("select[name=matching_bonus_time]").val("<?php echo e($general->matching_bonus_time); ?>");
            $("select[name=weekly_time]").val("<?php echo e($general->matching_when); ?>");
            $("select[name=monthly_time]").val("<?php echo e($general->matching_when); ?>");
            $("select[name=daily_time]").val("<?php echo e($general->matching_when); ?>");

            $('select[name=matching_bonus_time]').on('change', function () {
                matchingBonus($(this).val());
            });

            matchingBonus($('select[name=matching_bonus_time]').val());

            function matchingBonus(matching_bonus_time) {
                if (matching_bonus_time == 'daily') {
                    document.getElementById('weekly_time').style.display = 'none';
                    document.getElementById('monthly_time').style.display = 'none'
                    document.getElementById('daily_time').style.display = 'block'

                } else if (matching_bonus_time == 'weekly') {
                    document.getElementById('weekly_time').style.display = 'block';
                    document.getElementById('monthly_time').style.display = 'none'
                    document.getElementById('daily_time').style.display = 'none'
                } else if (matching_bonus_time == 'monthly') {
                    document.getElementById('weekly_time').style.display = 'none';
                    document.getElementById('monthly_time').style.display = 'block'
                    document.getElementById('daily_time').style.display = 'none'
                }
            }
        })(jQuery)

    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/safeworl/public_html/core/resources/views/admin/setting/general_setting.blade.php ENDPATH**/ ?>