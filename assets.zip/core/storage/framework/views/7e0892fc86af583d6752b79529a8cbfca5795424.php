<?php $__env->startSection('panel'); ?>
    <div class="row">

        <div class="col-lg-12">
            <div class="card b-radius--10 overflow-hidden">
                <div class="card-body p-0">
                    <div class="table-responsive--md table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Sl'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Username'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('BV'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Position'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Detail'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Date'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('Sl'); ?>"><?php echo e($logs->firstItem()+$key); ?></td>

                                    <td data-label="<?php echo app('translator')->get('Username'); ?>"><a href="<?php echo e(route('admin.users.detail', @$data->user_id)); ?>"><?php echo e(@$data->user->username); ?></a></td>

                                    <td data-label="<?php echo app('translator')->get('BV'); ?>" class="budget">
                                        <strong <?php if($data->trx_type == '+'): ?> class="text-success"
                                                <?php else: ?> class="text-danger" <?php endif; ?>> <?php echo e(($data->trx_type == '+') ? '+':'-'); ?> <?php echo e(getAmount($data->amount)); ?></strong>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Position'); ?>">
                                        <?php if($data->position == 1): ?><span class="badge badge--success"><?php echo app('translator')->get('Left'); ?></span>
                                        <?php else: ?>
                                            <span class="badge badge--primary"><?php echo app('translator')->get('Right'); ?></span>
                                        <?php endif; ?></td>
                                    <td data-label="<?php echo app('translator')->get('Detail'); ?>"><?php echo e($data->details); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Date'); ?>"><?php echo e($data->created_at != ''? date('d/m/y  g:i A',strtotime($data->created_at)): __('Not Assign')); ?></td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e(__($empty_message)); ?></td>
                                </tr>
                            <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer py-4">
                    <?php echo e($logs->links('admin.partials.paginate')); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('breadcrumb-plugins'); ?>
    <?php if(request()->routeIs('admin.users.transactions')): ?>
        <form action="" method="GET" class="form-inline float-sm-right bg--white">
            <div class="input-group has_append">
                <input type="text" name="search" class="form-control" placeholder="<?php echo app('translator')->get('TRX'); ?>" value="<?php echo e($search ?? ''); ?>">
                <div class="input-group-append">
                    <button class="btn btn--primary" type="submit"><i class="fa fa-search"></i></button>
                </div>
            </div>
        </form>
    <?php else: ?>
        <form action="<?php echo e(route('admin.report.transaction.search')); ?>" method="GET"
              class="form-inline float-sm-right bg--white">
            <div class="input-group has_append">
                <input type="text" name="search" class="form-control" placeholder="<?php echo app('translator')->get('TRX / Username'); ?>"
                       value="<?php echo e($search ?? ''); ?>">
                <div class="input-group-append">
                    <button class="btn btn--primary" type="submit"><i class="fa fa-search"></i></button>
                </div>
            </div>
        </form>
    <?php endif; ?>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/safeworl/public_html/core/resources/views/admin/reports/bvLog.blade.php ENDPATH**/ ?>