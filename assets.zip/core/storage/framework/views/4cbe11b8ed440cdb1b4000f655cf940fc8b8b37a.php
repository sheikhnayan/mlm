<?php $__env->startSection('content'); ?>
    <?php echo $__env->make($activeTemplate.'layouts.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="account-section padding-bottom padding-top">
        <div class="container">
            <div class="signup-area account-area">
                <div class="row m-0 justify-content-center">
                    <div class="col-lg-6 p-0">
                        <div class="common-form-style bg-one login-account account-wrapper">
                            <h4 class="title"><?php echo app('translator')->get('Reset Password'); ?></h4>
                            <form class="create-account-form" method="post" action="<?php echo e(route('user.password.update')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="email" value="<?php echo e($email); ?>">
                                <input type="hidden" name="token" value="<?php echo e($token); ?>">
                                <div class="form-group my-3">
                                    <input type="Password" name="password"   placeholder="<?php echo app('translator')->get('Password'); ?>">
                                </div>
                                <div class="form-group my-3">
                                    <input type="Password" name="password_confirmation"  placeholder="<?php echo app('translator')->get('Confirm Password'); ?>">
                                </div>
                                <div class="form-group">
                                    <input type="submit" value="<?php echo app('translator')->get('Change Password'); ?>">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/user/auth/passwords/reset.blade.php ENDPATH**/ ?>