<?php $__env->startSection('content'); ?>

    <?php echo $__env->make($activeTemplate.'layouts.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <section class="account-section padding-bottom padding-top">
        <div class="container">
            <div class="account-wrapper">
                <div class="login-area account-area">
                    <div class="row m-0">
                        <div class="col-lg-4 p-0">
                            <div class="change-catagory-area bg_img"
                                 data-background="<?php echo e(getImage('assets/images/frontend/sign_up/' . @$content->data_values->background_image, '450x970')); ?>">
                                <h4 class="title"><?php echo e(__(@$content->data_values->login_section_title)); ?></h4>
                                <p><?php echo e(__(@$content->data_values->login_section_short_details)); ?></p>
                                <a href="<?php echo e(route('user.login')); ?>"
                                   class="custom-button account-control-button"><?php echo app('translator')->get('Login Account'); ?></a>
                            </div>
                        </div>
                        <div class="col-lg-8 p-0">
                            <div class="common-form-style bg-one create-account">
                                <h4 class="title"><?php echo e(__(@$content->data_values->title)); ?></h4>
                                <p class="mb-sm-4 mb-3"><?php echo e(__(@$content->data_values->short_details)); ?></p>
                                <form class="create-account-form form-row" method="post"
                                      action="<?php echo e(route('user.register')); ?>" onsubmit="return submitUserForm();">
                                    <?php echo csrf_field(); ?>

                                    <?php if($ref_user == null): ?>

                                        <div class="col-md-6 ">
                                            <div class="form-group ">
                                                <input type="text" name="referral" class="referral"
                                                       value="<?php echo e(old('referral')); ?>" id="ref_name"
                                                       placeholder="<?php echo app('translator')->get('Enter referral username'); ?>*" required>
                                                <div id="ref"></div>
                                                <span id="referral"></span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 ">
                                            <div class="form-group ">
                                                <select name="position" class="position" id="position" required
                                                        disabled>
                                                    <option value=""><?php echo app('translator')->get('Select position'); ?>*</option>
                                                    <?php $__currentLoopData = mlmPositions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=> $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($k); ?>"><?php echo app('translator')->get($v); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <span id="position-test"><span
                                                        class="text-danger"><?php echo app('translator')->get('Please enter referral username first'); ?></span></span>
                                            </div>
                                        </div>
                                        <input type="hidden" value="<?php echo e(old('referral')); ?>" name="bv">
                                        <input type="hidden" value="random" name="random">
                                    <?php else: ?>
                                        <div class="col-md-6 ">
                                            <div class="form-group ">
                                                <input type="text" name="referral" class="referral"
                                                       value="<?php echo e($ref_user->username); ?>"
                                                       placeholder="<?php echo app('translator')->get('Enter referral username'); ?>*" required
                                                       readonly>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group ">
                                                <select class="position" id="position" required disabled>
                                                    <option value=""><?php echo app('translator')->get('Select position'); ?>*</option>
                                                    <?php $__currentLoopData = mlmPositions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=> $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php if($position == $k): ?> selected
                                                                <?php endif; ?> value="<?php echo e($k); ?>"><?php echo app('translator')->get($v); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <input type="hidden" name="position" value="<?php echo e($position); ?>">
                                                <?php echo $joining; ?>
                                            </div>
                                        </div>
                                        <input type="hidden" value="<?php echo e($join_under->id); ?>" name="bv">
                                        <input type="hidden" value="not_random" name="random">
                                    <?php endif; ?>

                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <input type="text" name="firstname" value="<?php echo e(old('firstname')); ?>"
                                                   autocomplete="off" placeholder="<?php echo app('translator')->get('Enter your first name'); ?>*"
                                                   required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <input type="text" name="lastname" value="<?php echo e(old('lastname')); ?>"
                                                   placeholder="<?php echo app('translator')->get('Enter your last name'); ?>*" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <input type="email" name="email" value="<?php echo e(old('email')); ?>"
                                                   placeholder="<?php echo app('translator')->get('Enter your email'); ?>*" required>
                                        </div>
                                    </div>

                                    <div class="col-md-6">

                                        <div class="input-group mb-3 input-group-custom">
                                            <div class="input-group-prepend">
                                                <select name="country_code" class="input-group-text">
                                                    <?php echo $__env->make('partials.country_code', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </select>
                                            </div>
                                            <input type="text" class="form-control" name="mobile"
                                                   placeholder="<?php echo app('translator')->get('Your Phone Number'); ?>" required>
                                        </div>

                                    </div>


                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <input type="text" name="country" placeholder="<?php echo app('translator')->get('Country'); ?>" readonly/>
                                        </div>
                                    </div>


                                    <div class="col-md-6 mb-3">
                                        <div class="form-group ">
                                            <input type="text" name="city" value="<?php echo e(old('city')); ?>"
                                                   placeholder="<?php echo app('translator')->get('Enter your city'); ?>*" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group ">
                                            <input type="text" name="state" value="<?php echo e(old('state')); ?>"
                                                   placeholder="<?php echo app('translator')->get('Enter your state'); ?>*" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group ">
                                            <input type="text" name="zip" value="<?php echo e(old('zip')); ?>"
                                                   placeholder="<?php echo app('translator')->get('Enter your zip'); ?>*" required>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group mb-3">
                                            <input type="text" name="username" value="<?php echo e(old('username')); ?>"
                                                   placeholder="<?php echo app('translator')->get('Enter your username'); ?>*" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <input type="password" name="password" id="myInputTwo"
                                                   placeholder="<?php echo app('translator')->get('Password'); ?>*">
                                        </div>

                                        <?php if($general->secure_password): ?>
                                            <p class="text-danger my-1 capital"><?php echo app('translator')->get('At least 1 capital letter is required'); ?></p>
                                            <p class="text-danger my-1 number"><?php echo app('translator')->get('At least 1 number is required'); ?></p>
                                            <p class="text-danger my-1 special"><?php echo app('translator')->get('At least 1 special character is required'); ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <input type="password" name="password_confirmation" id="myInputTwo"
                                                   placeholder="<?php echo app('translator')->get('Confirm password'); ?>*" required>
                                        </div>
                                    </div>

                                    <?php if(reCaptcha()): ?>
                                        <div class="col-md-6 ">
                                            <div class="form-group my-3">
                                                <?php echo reCaptcha(); ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <div class="form-group col-md-12">
                                        <?php echo $__env->make($activeTemplate.'partials.custom-captcha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>


                                    <div class="form-group col-md-12">
                                        <input type="submit" value="Create an Account">
                                    </div>
                                </form>
                                <p class="terms-and-conditions"><?php echo app('translator')->get('First Read Our All'); ?> <a
                                        href="<?php echo e(route('terms')); ?>"> <?php echo app('translator')->get('Terms & Conditions'); ?></a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>

        (function ($) {
            "use strict";
            var not_select_msg = $('#position-test').html();
            $(document).on('keyup', '#ref_name', function () {
                var ref_id = $('#ref_name').val();
                var token = "<?php echo e(csrf_token()); ?>";
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('check.referral')); ?>",
                    data: {
                        'ref_id': ref_id,
                        '_token': token
                    },
                    success: function (data) {
                        if (data.success) {
                            $('select[name=position]').removeAttr('disabled');
                            $('#position-test').text('');
                        } else {
                            $('select[name=position]').attr('disabled', true);
                            $('#position-test').html(not_select_msg);
                        }
                        $("#ref").html(data.msg);
                    }
                });
            });
            $(document).on('change', '#position', function () {
                updateHand();
            });

            function updateHand() {
                var pos = $('#position').val();
                var referrer_id = $('#referrer_id').val();
                var token = "<?php echo e(csrf_token()); ?>";
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('get.user.position')); ?>",
                    data: {
                        'referrer': referrer_id,
                        'position': pos,
                        '_token': token
                    },
                    success: function (data) {
                        $("#position-test").html(data.msg);
                    }
                });
            }

            <?php if(@$country_code): ?>
            $(`option[data-code=<?php echo e($country_code); ?>]`).attr('selected', '');
            <?php endif; ?>
            $('select[name=country_code]').change(function () {
                $('input[name=country]').val($('select[name=country_code] :selected').data('country'));
            }).change();

            function submitUserForm() {
                var response = grecaptcha.getResponse();
                if (response.length == 0) {
                    document.getElementById('g-recaptcha-error').innerHTML = '<span style="color:red;"><?php echo app('translator')->get("Captcha field is required."); ?></span>';
                    return false;
                }
                return true;
            }

            function verifyCaptcha() {
                document.getElementById('g-recaptcha-error').innerHTML = '';
            }

            <?php if($general->secure_password): ?>
            $('input[name=password]').on('input', function () {
                var password = $(this).val();
                var capital = /[ABCDEFGHIJKLMNOPQRSTUVWXYZ]/;
                var capital = capital.test(password);
                if (!capital) {
                    $('.capital').removeClass('d-none');
                } else {
                    $('.capital').addClass('d-none');
                }
                var number = /[123456790]/;
                var number = number.test(password);
                if (!number) {
                    $('.number').removeClass('d-none');
                } else {
                    $('.number').addClass('d-none');
                }
                var special = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
                var special = special.test(password);
                if (!special) {
                    $('.special').removeClass('d-none');
                } else {
                    $('.special').addClass('d-none');
                }

            });
            <?php endif; ?>

            <?php if(old('position')): ?>
            $(`select[name=position]`).val('<?php echo e(old('position')); ?>');
            <?php endif; ?>

        })(jQuery);


    </script>



<?php $__env->stopPush(); ?>



<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/user/auth/register.blade.php ENDPATH**/ ?>