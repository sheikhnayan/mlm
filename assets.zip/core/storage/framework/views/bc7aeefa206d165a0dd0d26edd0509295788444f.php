<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset($activeTemplateTrue.'frontend/js/jquery.inputLettering.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset($activeTemplateTrue.'js/jquery.inputLettering.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function ($) {
            "use strict";
            $('#phoneInput').letteringInput({
                    inputClass: 'letter',
                    onLetterKeyup: function ($item, event) {
                        console.log('$item:', $item);
                        console.log('event:', event);
                    },
                    onSet: function ($el, event, value) {
                        console.log('element:', $el);
                        console.log('event:', event);
                        console.log('value:', value);
                    }
                });

        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>



<?php $__env->startPush('script'); ?>
    <script>
        (function ($) {
            "use strict";
            $('#phoneInput').letteringInput({
                inputClass: 'letter',
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php /**PATH /home/safeworl/public_html/core/resources/views/partials/phoneInputScript.blade.php ENDPATH**/ ?>