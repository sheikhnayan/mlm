<?php
    $marketing_tools = getContent('marketing_tool.element');
?>
<?php if($marketing_tools): ?>

    <section class="feature-section padding-top padding-bottom">
        <div class="container">
            <div class="row justify-content-center mb-30-none">
                <?php $__currentLoopData = $marketing_tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marketing_tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-12">
                        <div class="feature-item">
                            <div class="feature-header">
                                <div class="icon">
                                    <i class="fas fa-bullhorn"></i>
                                </div>
                                <h6 class="title"><?php echo e(__(@$marketing_tool->data_values->title)); ?></h6>
                            </div>
                            <div class="feature-body">
                                <p><?php echo @$marketing_tool->data_values->description; ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>


<?php endif; ?>
<?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/sections/marketing_tool.blade.php ENDPATH**/ ?>