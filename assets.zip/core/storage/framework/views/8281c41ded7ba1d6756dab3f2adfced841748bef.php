<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> <?php echo e($general->sitename); ?> - <?php echo e(__(@$page_title)); ?> </title>
    <link rel="shortcut icon" href="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/favicon.png')); ?>" type="image/x-icon">
    <?php echo $__env->make('partials.seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue . 'frontend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue . 'frontend/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue . 'frontend/css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue . 'frontend/css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue . 'frontend/css/swiper.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue . 'frontend/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue . 'frontend/css/odometer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue . 'frontend/css/flaticon.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue . 'frontend/css/line-awesome.min.css')); ?>">

    <?php echo $__env->yieldPushContent('style-lib'); ?>
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue . 'frontend/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue . 'frontend/css/custom.css')); ?>">
    <?php echo $__env->yieldPushContent('css'); ?>
    <link rel="stylesheet" href='<?php echo e(asset($activeTemplateTrue."frontend/css/color.php?color=$general->base_color")); ?>'>

    <?php echo $__env->yieldPushContent('style'); ?>
</head>

<body>

<?php echo $__env->yieldPushContent('facebook'); ?>

<div class="overlay"></div>
<a href="#0" class="scrollToTop"><i class="flaticon-arrow"></i></a>
<div class="overlayer" id="overlayer">
    <div class="loader">
        <div class="loader-inner"></div>
    </div>
</div>

<header>


    <div class="header-top">
        <div class="container">
            <div class="header-top-area">


                <div class="header-top-item">
                    <a href="Mailto:<?php echo e(@$contact->data_values->email_address); ?>"><i class="fa fa-envelope"></i><?php echo e(@$contact->data_values->email_address); ?></a>
                </div>
                <div class="header-top-item">
                    <a href="tel:<?php echo e(@$contact->data_values->contact_number); ?>"><i class="fa fa-mobile-alt"></i><?php echo e(@$contact->data_values->contact_number); ?></a>
                </div>

                <div class="header-top-item ml-auto d-none d-sm-block">
                    <select class="select-bar langSel">
                        <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->code); ?>"
                                    <?php if(session('lang') == $item->code): ?> selected <?php endif; ?>><?php echo e(__($item->name)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>



            </div>
        </div>
    </div>




    <div class="header-bottom">
        <div class="container">
            <div class="header-area">
                <div class="logo">
                    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>"
                                                alt="logo"></a>
                </div>
                <ul class="menu">
                    <li><a href="<?php echo e(url('/')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('pages',[$data->slug])); ?>"><?php echo e(trans($data->name)); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('blog')); ?>"><?php echo app('translator')->get('Blog'); ?></a></li>
                    <li><a href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a></li>
                    <?php if(auth()->guard()->check()): ?>
                        <li><a href="javascript:void(0)"><?php echo e(auth()->user()->username); ?></a>
                            <ul class="submenu">
                                <li><a href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a></li>
                                <li><a href="<?php echo e(route('user.logout')); ?>"><?php echo app('translator')->get('Logout'); ?></a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li>
                            <a href="javascript:void(0)"><?php echo app('translator')->get('Account'); ?></a>
                            <ul class="submenu">
                                <li><a href="<?php echo e(route('user.login')); ?>"><?php echo app('translator')->get('Sign In'); ?></a>
                                </li>
                                <li><a href="<?php echo e(route('user.register')); ?>"><?php echo app('translator')->get('Sign Up'); ?></a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>

                <select class="select-bar d-sm-none ml-auto mr-3 langSel">
                    <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->code); ?>"
                                <?php if(session('lang') == $item->code): ?> selected <?php endif; ?>><?php echo e(__($item->name)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <div class="header-bar d-lg-none">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- ============Header Section Ends Here============ -->
<?php echo $__env->yieldContent('content'); ?>
<!-- ============Footer Section Starts Here============ -->

<footer>
    <div class="footer-top">
        <div class="container">
            <div class="logo">
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="logo"></a>
            </div>
            <p><?php echo e(__(@$footer->data_values->website_footer)); ?></p>
            <ul class="social-icons">
                <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(@$social->data_values->url); ?>" target="_blank"
                           title="<?php echo e(@$social->data_values->title); ?>"><?php echo @$social->data_values->social_icon; ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <p><?php echo e(__(@$footer->data_values->copyright)); ?></p>
    </div>
</footer>
<!-- ============Footer Section Ends Here============ -->
<script src="<?php echo e(asset($activeTemplateTrue . 'frontend/js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset($activeTemplateTrue . 'frontend/js/modernizr-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset($activeTemplateTrue . 'frontend/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset($activeTemplateTrue . 'frontend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset($activeTemplateTrue . 'frontend/js/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset($activeTemplateTrue . 'frontend/js/magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset($activeTemplateTrue . 'frontend/js/swiper.min.js')); ?>"></script>
<script src="<?php echo e(asset($activeTemplateTrue . 'frontend/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset($activeTemplateTrue . 'frontend/js/odometer.min.js')); ?>"></script>
<script src="<?php echo e(asset($activeTemplateTrue . 'frontend/js/viewport.jquery.js')); ?>"></script>
<script src="<?php echo e(asset($activeTemplateTrue . 'frontend/js/nice-select.js')); ?>"></script>
<?php echo $__env->yieldPushContent('script-lib'); ?>

<script src="<?php echo e(asset($activeTemplateTrue . 'frontend/js/main.js')); ?>"></script>

<?php echo $__env->yieldPushContent('js'); ?>
<?php echo $__env->make('partials.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.plugins', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    $(document).on("change", ".langSel", function () {
        window.location.href = "<?php echo e(url('/')); ?>/change/" + $(this).val();
    });
</script>
<?php echo $__env->yieldPushContent('script'); ?>

</body>
</html>
<?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/layouts/master.blade.php ENDPATH**/ ?>