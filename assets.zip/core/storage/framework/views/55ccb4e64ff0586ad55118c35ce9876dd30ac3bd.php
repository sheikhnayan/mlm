<?php
    $latestTrx = getContent('latestTrx.content', true);
    $deposits = App\Models\Deposit::latest()->where('status', 1)->take(10)->with('user')->get();
    $withdraws = App\Models\Withdrawal::latest()->where('status', 1)->take(10)->with('user')->get();
?>

<!--<section class="transaction-section padding-top section-bg padding-bottom">-->
<!--    <div class="container">-->
<!--        <div class="row">-->
<!--            <div class="col-12">-->
<!--                <div class="section-header">-->
<!--                    <h2 class="title"><?php echo app('translator')->get(@$latestTrx->data_values->heading); ?></h2>-->
<!--                    <p><?php echo app('translator')->get(@$latestTrx->data_values->sub_heading); ?></p>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--        <div class="tab deposit-tab">-->
<!--            <ul class="tab-menu text-center">-->
<!--                <li class="active custom-button"><?php echo app('translator')->get('Latest Deposits'); ?></li>-->
<!--                <li class="custom-button"><?php echo app('translator')->get('Latest Withdraws'); ?></li>-->
<!--            </ul>-->
<!--            <div class="tab-area">-->
<!--                <div class="tab-item active">-->
<!--                    <div class="deposite-table">-->
<!--                        <table>-->
<!--                            <thead>-->
<!--                            <tr class="bg-2">-->
<!--                                <th><?php echo app('translator')->get('Name'); ?></th>-->
<!--                                <th><?php echo app('translator')->get('Plan'); ?></th>-->
<!--                                <th><?php echo app('translator')->get('Date'); ?></th>-->
<!--                                <th><?php echo app('translator')->get('Amount'); ?></th>-->
<!--                            </tr>-->
<!--                            </thead>-->
<!--                            <tbody>-->
<!--                            <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
<!--                                <tr>-->
<!--                                    <td data-input="<?php echo app('translator')->get('Name'); ?>">-->
<!--                                        <div class="author">-->
<!--                                            <div class="thumb">-->
<!--                                                <img src="<?php echo e(getImage('assets/images/user/profile/' . @$deposit->user->image, '150x150')); ?>" alt="jpg">-->
<!--                                            </div>-->
<!--                                            <div class="content"><?php echo e(@$deposit->user->fullName); ?></div>-->
<!--                                        </div>-->
<!--                                    </td>-->
<!--                                    <td data-input="<?php echo app('translator')->get('Plan'); ?>"><?php echo e(@$deposit->user->plan->name ?? 'No plan'); ?></td>-->
<!--                                    <td data-input="<?php echo app('translator')->get('Date'); ?>"><?php echo e(showDateTime($deposit->created_at , $format = 'd F, Y')); ?></td>-->
<!--                                    <td data-input="<?php echo app('translator')->get('Amount'); ?>"><?php echo e(getAmount($deposit->amount)); ?> <?php echo e($general->cur_text); ?></td>-->
<!--                                </tr>-->
<!--                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
<!--                            </tbody>-->
<!--                        </table>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="tab-item">-->
<!--                    <div class="deposite-table">-->
<!--                        <table>-->
<!--                            <thead>-->
<!--                            <tr class="bg-2">-->
<!--                                <th><?php echo app('translator')->get('Name'); ?></th>-->
<!--                                <th><?php echo app('translator')->get('Plan'); ?></th>-->
<!--                                <th><?php echo app('translator')->get('Date'); ?></th>-->
<!--                                <th><?php echo app('translator')->get('Amount'); ?></th>-->
<!--                            </tr>-->
<!--                            </thead>-->
<!--                            <tbody>-->
<!--                            <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
<!--                                <tr>-->
<!--                                    <td data-input="<?php echo app('translator')->get('Name'); ?>">-->
<!--                                        <div class="author">-->
<!--                                            <div class="thumb">-->
<!--                                                <img-->
<!--                                                    src="<?php echo e(getImage('assets/images/user/profile/' . @$withdraw->user->image, '150x150')); ?>"-->
<!--                                                    alt="jpg">-->
<!--                                            </div>-->
<!--                                            <div class="content">-->
<!--                                                <?php echo e(@$withdraw->user->fullName); ?>-->
<!--                                            </div>-->
<!--                                        </div>-->
<!--                                    </td>-->
<!--                                    <td data-input="<?php echo app('translator')->get('Plan'); ?>"><?php echo e(@$deposit->user->plan->name ?? 'No plan'); ?></td>-->
<!--                                    <td data-input="<?php echo app('translator')->get('Date'); ?>"><?php echo e(showDateTime($withdraw->created_at , $format = 'd F, Y')); ?></td>-->
<!--                                    <td data-input="<?php echo app('translator')->get('Amount'); ?>"><?php echo e(getAmount($withdraw->amount)); ?> <?php echo e($general->cur_text); ?></td>-->
<!--                                </tr>-->
<!--                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
<!--                            </tbody>-->
<!--                        </table>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</section>-->
<?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/sections/latestTrx.blade.php ENDPATH**/ ?>