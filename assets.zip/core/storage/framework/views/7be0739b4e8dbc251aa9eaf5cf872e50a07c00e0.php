<?php $__env->startSection('content'); ?>

    <?php echo $__env->make($activeTemplate.'layouts.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="blog-section padding-top padding-bottom">
        <div class="container">

            <div class="row mb-30-none">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-xl-4 col-sm-10">
                        <div class="post-item">
                            <div class="post-thumb c-thumb">
                                <a href="<?php echo e(route('singleBlog', [slug(@$blog->data_values->title), $blog])); ?>">
                                    <img src="<?php echo e(getImage('assets/images/frontend/blog/thumb_'.@$blog->data_values->blog_image, '410x410')); ?>" alt="blog">
                                </a>
                            </div>
                            <div class="post-content">
                                <h5 class="title">
                                    <a href="<?php echo e(route('singleBlog', [slug(@$blog->data_values->title), $blog])); ?>"><?php echo e(__(@$blog->data_values->title)); ?></a>
                                </h5>
                                <ul class="meta-post">
                                    <li><i class="fas fa-calendar-day"></i><span><?php echo e(showDateTime($blog->created_at,  $format = 'd M, Y')); ?></span></li>
                                </ul>
                                <div class="entry-content">
                                    <p><?php echo e(__(str_limit(strip_tags(@$blog->data_values->description) , 175))); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>


    <?php if($sections->secs != null): ?>
        <?php $__currentLoopData = json_decode($sections->secs); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make($activeTemplate.'sections.'.$sec, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>


<?php $__env->stopSection(); ?>



<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/blog.blade.php ENDPATH**/ ?>