<?php
    $counterCaption = getContent('counter.content', true);
    $counters = getContent('counter.element');
?>


<div class="counter-section padding-top padding-bottom bg-overlay bg_fixed bg_img"
     data-background="<?php echo e(getImage('assets/images/frontend/counter/' . @$counterCaption->data_values->background_image, '1920x600')); ?>">
    <div class="container">
        <div class="counter-wrapper">
            <?php $__currentLoopData = $counters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="counter-item">
                    <div class="counter-header">
                        <h2 class="title" ><?php echo e(@$counter->data_values->counter_digit); ?></h2>
                    </div>
                    <h6 class="subtitle"><?php echo e(@__($counter->data_values->title)); ?> </h6>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH /home/safeworl/public_html/core/resources/views/templates/basic/sections/counter.blade.php ENDPATH**/ ?>